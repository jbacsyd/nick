function sO(object) {
    return Object.keys(object).length;
}
var wait = global.nodemodule["wait-for-stuff"];
var emoji = function(type, data) {
	var fb = data.facebookapi;
	var msg = data.msgdata;
	var threadID = msg.threadID;
	var senderID = msg.senderID;
	try {
		if (data.args.length > 1) {
			var emoji = data.args[1]
			fb.changeThreadEmoji(emoji, threadID, (err) => {
        		if(err) return console.error(err);
    		});
    		return {
				handler: "internal",
				data: "👌"
			}
		} else {
			data.return({
				handler: "internal",
				data: "Thây đổi emoji"
			})
		}
	} catch (e) {
		data.return({
			handler: 'internal',
			data: 'error!'
		})
	}
}
var nick = function(type, data) {
	var fb = data.facebookapi;
	var msg = data.msgdata;
	var threadID = msg.threadID;
	var senderID = msg.senderID;
	var mentions = data.mentions;
	//var nicks = data.args.slice(1).join(" ");
	try {
		if (sO(mentions) == 1) {
			var tag = Object.keys(mentions)[0].slice(3)
			var name = data.args.slice(4).join(" ");
			try {
				fb.changeNickname(name, threadID, tag, (err) => {
					if (err) return data.log(err)
				});
				return {
					handler: "internal",
					data: "👌"
				}
			} catch (ex) {return data.log(ex)}
		} else {
			var nicks = data.args.slice(1).join(" ");
			try {
				fb.changeNickname(nicks, threadID, senderID, (err) => {
					if (err) return data.log(err)
				})
				return {
					handler: "internal",
					data: "👌"
				}
			} catch (ex) {return data.log(ex)}
		}
	} catch (ex) {
		return {
			handler: "internal",
			data: "Error!"
		}
	}
}
var kick = function(type, data) {
	var mentions = data.mentions;
	try {
		var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
		var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
		if (adminIDs.indexOf(data.msgdata.senderID) != -1) {
			for (var y in data.mentions) {
				var id = y;
				data.log(id);
				if(id != "FB-"+data.facebookapi.getCurrentUserID()) {
				 	var name = global.data.cacheName["FB-" + id.slice(3,id.length)]
				 	data.facebookapi.removeUserFromGroup(id.slice(3,id.length), data.msgdata.threadID, function(error) {
				 		if(error) {
				 			return {
				 				handler: "internal",
				 				data: "Vui lòng set quyền quản trị cho bot!"
				 			}
				 		} else {
				 			data.return({
				 				handler: "internal",
				 				data: {
				 					body: `@${name} Đã bị kick ra khỏi nhóm`,
				 					mentions: {
				 						tag: `@${name}`,
				 						id: Object.keys(mentions)[0].slice(3),
				 						fromIndex: 0
				 					}
				 				}
				 	 		});
				 		}
				 	});
				}
			}
		} else {
			return {
				handler: "internal",
				data: "Bạn đếch có quyền để dùng lệnh này 😏👌"
			}
		}
	} catch (ex) {
		data.log(ex)
		data.return({
			handler: 'internal',
			data: global.config.commandPrefix+"kick @<mentions>"
		})
	}
}
var groupname = function(type, data) {
	var name = data.args.slice(1).join(" ");
	data.facebookapi.setTitle(name, data.msgdata.threadID);
	var str = 'Đã thay đổi tên nhóm là '+name
		return {
			handler: "internal",
			data: str
		}
}
module.exports = {
	nick: nick,
	emoji: emoji,
	kick: kick,
	groupname: groupname
}
	